exports = function(arg){
  
  let offset = 5000;
 
  
  
  const pipeline = [{
    $group: {
        _id: "Fleet",
        fleet: {
            $addToSet: "$registration"
        }
    }
  }];
  
  const saveData = function(fleetNums) {
    console.log("Ran at: ", new Date());
    
    https.get(url, {
      headers: {
        'User-Agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.77 Safari/537.36',
      },
    }, (resp) => {
      let data = '';
    
      resp.on('data', (chunk) => {
        data += chunk;
      });
    
      resp.on('end', () => {
        let flightData = JSON.parse(data);
        delete flightData.stats;
        delete flightData.version;
        delete flightData.full_count;
        
        for (const [ID, dataArray] of Object.entries(flightData)) {
          const isFirePlane = (fleetNums.indexOf(String(dataArray[9])) > -1);
          if(isFirePlane) {
            let record = {
              icaoAddress: dataArray[0],
              location: { type: "Point", coordinates: [ dataArray[2], dataArray[1] ] },
              track: dataArray[3],
              calibratedAltitude: dataArray[4],
              groundSpeedKnots: dataArray[5],
              squawk: dataArray[6],
              time: new Date( dataArray[10] * 1000 ),
              modelS: dataArray[8],
              registration: dataArray[9],
              originAirport: dataArray[11],
              destinationAirport: dataArray[12],
              flightCode: dataArray[13],
              callsign: dataArray[16],
              airlineCode: dataArray[18],
              vendorID: ID,
              grounded: dataArray[14] == 1 ? true : false,
              feederStationCode: dataArray[7],
              verticalSpeedFPM: dataArray[15],
              unknownField: dataArray[17],
            };
            
            // console.log(JSON.stringify(record));
            const insertResult = points.insertOne(record);
    
            const updateResult = flights.updateOne(
              {
                lastPoint: {'$gte': new Date(Date.now()-60000)},
                registration: dataArray[9],
              },
              {
                $set: { 
                  lastPoint: new Date(), 
                  'flightPath.type': 'MultiPoint',
                  status: dataArray[14] == 1 ? 'grounded' : 'flying'
                },
                $push: {
                  altitude: dataArray[4], 
                  'flightPath.coordinates': [dataArray[2], dataArray[1]],
                  timings: record.time
                },
                $setOnInsert: {
                  created: new Date(),
                  registration:dataArray[9],
                  aircraftType:'',
                  characteristic:'',
                  callsign:'',
                  modeS:'',
                }
              },
              {
                upsert: true
              }
            );
            
            console.log(JSON.stringify(updateResult));
          }
        }
      });
    
    }).on("error", (err) => {
      console.log("Error: " + err.message);
    });      
  }
  
  const fleetCollection = context.services.get("mongodb-atlas").db("Fire").collection("Fleet");
  const url = "https://data-live.flightradar24.com/zones/fcgi/feed.js?faa=1&bounds=42.552%2C35.646%2C-128.805%2C-112.069&satellite=1&mlat=1&flarm=1&adsb=1&gnd=1&air=1&vehicles=1&estimated=0&maxage=10&gliders=0&altitude=0,10000&stats=1";
  const https = require('https');
  const points = context
  .services
  .get("mongodb-atlas")
  .db("Fire")
  .collection("Points");
  
  const flights = context
  .services
  .get("mongodb-atlas")
  .db("Fire")
  .collection("Flights");
  
  fleetCollection.aggregate(pipeline).toArray()
    .then(fleetArray => {
      const fleetNumbers = fleetArray[0].fleet;
      
      setTimeout(function() {saveData(fleetNumbers)}, (0+offset));
      for (let step = 0; step < 5; step++) {
        let nextTime = ((step+1)*10000)+offset;
        setTimeout(function() {saveData(fleetNumbers)}, nextTime);
      }
    })
    .catch(err => console.error(`Agg Error: ${err}`))
    
    
};