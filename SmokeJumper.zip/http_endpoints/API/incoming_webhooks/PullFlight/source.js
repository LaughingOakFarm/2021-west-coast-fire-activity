exports = function(payload, response) {

  const flights = context
  .services
  .get("mongodb-atlas")
  .db("Fire")
  .collection("Flights");
    
  return flights.findOne({_id: new BSON.ObjectId('60c6c894657fd22d32babc02')})
    .then(flight => {
      return flight;
    })
    .catch(err => console.error(`Failed to find document: ${err}`));
};
